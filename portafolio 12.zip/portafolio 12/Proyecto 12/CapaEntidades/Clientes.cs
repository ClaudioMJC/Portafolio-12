﻿using System;

namespace CapaEntidades
{
    public class Clientes
    {
        private int id_Cliente;
        private string nombre;
        private string telefono;
        private string direccion;

        //constructores
        public Clientes()
        {
            id_Cliente = 0;
            nombre = "";
            telefono = "";
            direccion = "";
        }
        public Clientes(int id_Cliente, string nombre, string telefono, string direccion)
        {
            this.id_Cliente = id_Cliente;
            this.nombre = nombre;
            this.telefono = telefono;
    }   }
}
