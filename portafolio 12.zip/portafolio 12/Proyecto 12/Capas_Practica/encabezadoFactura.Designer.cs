﻿namespace Capas_Practica
{
    partial class encabezadoFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new System.Windows.Forms.DataGridView();
            id_Factura = new System.Windows.Forms.DataGridViewTextBoxColumn();
            FECHA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ID_CLIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            SUBTOTAL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            IMPUESTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            MONTODESCUENTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { id_Factura, FECHA, ID_CLIENTE, SUBTOTAL, IMPUESTO, MONTODESCUENTO });
            dataGridView1.Location = new System.Drawing.Point(142, 114);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new System.Drawing.Size(465, 194);
            dataGridView1.TabIndex = 0;
            // 
            // id_Factura
            // 
            id_Factura.DataPropertyName = "ID_FACTURA";
            id_Factura.HeaderText = "ID_FACTURA";
            id_Factura.MinimumWidth = 8;
            id_Factura.Name = "id_Factura";
            id_Factura.Width = 150;
            // 
            // FECHA
            // 
            FECHA.DataPropertyName = "FECHA";
            FECHA.HeaderText = "FECHA";
            FECHA.MinimumWidth = 8;
            FECHA.Name = "FECHA";
            FECHA.Width = 150;
            // 
            // ID_CLIENTE
            // 
            ID_CLIENTE.DataPropertyName = "ID_CLIENTE";
            ID_CLIENTE.HeaderText = "ID_CLIENTE";
            ID_CLIENTE.MinimumWidth = 8;
            ID_CLIENTE.Name = "ID_CLIENTE";
            ID_CLIENTE.Width = 150;
            // 
            // SUBTOTAL
            // 
            SUBTOTAL.DataPropertyName = "SUBTOTAL";
            SUBTOTAL.HeaderText = "SUBTOTAL";
            SUBTOTAL.MinimumWidth = 8;
            SUBTOTAL.Name = "SUBTOTAL";
            SUBTOTAL.Width = 150;
            // 
            // IMPUESTO
            // 
            IMPUESTO.DataPropertyName = "IMPUESTO";
            IMPUESTO.HeaderText = "IMPUESTO";
            IMPUESTO.MinimumWidth = 8;
            IMPUESTO.Name = "IMPUESTO";
            IMPUESTO.Width = 150;
            // 
            // MONTODESCUENTO
            // 
            MONTODESCUENTO.DataPropertyName = "MONTODESCUENTO";
            MONTODESCUENTO.HeaderText = "MONTODESCUENTO";
            MONTODESCUENTO.MinimumWidth = 8;
            MONTODESCUENTO.Name = "MONTODESCUENTO";
            MONTODESCUENTO.Width = 150;
            // 
            // encabezadoFactura
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(dataGridView1);
            Name = "encabezadoFactura";
            Text = "encabezadoFactura";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_Factura;
        private System.Windows.Forms.DataGridViewTextBoxColumn FECHA;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_CLIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn SUBTOTAL;
        private System.Windows.Forms.DataGridViewTextBoxColumn IMPUESTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn MONTODESCUENTO;
    }
}