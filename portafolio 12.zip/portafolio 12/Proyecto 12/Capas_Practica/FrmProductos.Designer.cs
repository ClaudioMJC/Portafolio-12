﻿namespace Capas_Practica
{
    partial class FrmProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new System.Windows.Forms.DataGridView();
            ID_PRODUCTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            DESCRIPCION = new System.Windows.Forms.DataGridViewTextBoxColumn();
            PRECIOCOMPRA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            PRECIOVENTA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            GRAVADO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_PRODUCTO, DESCRIPCION, PRECIOCOMPRA, PRECIOVENTA, GRAVADO });
            dataGridView1.Location = new System.Drawing.Point(125, 87);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new System.Drawing.Size(489, 181);
            dataGridView1.TabIndex = 0;
            // 
            // ID_PRODUCTO
            // 
            ID_PRODUCTO.DataPropertyName = "ID_PRODUCTO)";
            ID_PRODUCTO.HeaderText = "ID_PRODUCTO";
            ID_PRODUCTO.MinimumWidth = 8;
            ID_PRODUCTO.Name = "ID_PRODUCTO";
            ID_PRODUCTO.Width = 150;
            // 
            // DESCRIPCION
            // 
            DESCRIPCION.DataPropertyName = "DESCRIPCION";
            DESCRIPCION.HeaderText = "DESCRIPCIÓN";
            DESCRIPCION.MinimumWidth = 8;
            DESCRIPCION.Name = "DESCRIPCION";
            DESCRIPCION.Width = 150;
            // 
            // PRECIOCOMPRA
            // 
            PRECIOCOMPRA.DataPropertyName = "PRECIOCOMPRA";
            PRECIOCOMPRA.HeaderText = "PRECIOCOMPRA";
            PRECIOCOMPRA.MinimumWidth = 8;
            PRECIOCOMPRA.Name = "PRECIOCOMPRA";
            PRECIOCOMPRA.Width = 150;
            // 
            // PRECIOVENTA
            // 
            PRECIOVENTA.HeaderText = "PRECIOVENTA";
            PRECIOVENTA.MinimumWidth = 8;
            PRECIOVENTA.Name = "PRECIOVENTA";
            PRECIOVENTA.Width = 150;
            // 
            // GRAVADO
            // 
            GRAVADO.HeaderText = "GRAVADO";
            GRAVADO.MinimumWidth = 8;
            GRAVADO.Name = "GRAVADO";
            GRAVADO.Width = 150;
            // 
            // FrmProductos
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(dataGridView1);
            Name = "FrmProductos";
            Text = "FrmProductos";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_PRODUCTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DESCRIPCION;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRECIOCOMPRA;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRECIOVENTA;
        private System.Windows.Forms.DataGridViewTextBoxColumn GRAVADO;
    }
}